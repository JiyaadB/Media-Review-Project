package ratings;

public class Reviewer {
    public String ID;

    public Reviewer(String I){
        ID = I;
    }

    public String getReviewerID(){
        return ID;
    }

    public void setReviewerID(String I){
        ID = I;
    }
    //
    public Rating rateSong(int r){
        Rating rate = new Rating(ID, r);
        return rate;
    }

}
