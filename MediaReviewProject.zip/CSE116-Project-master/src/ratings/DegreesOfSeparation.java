package ratings;

import java.util.ArrayList;
import java.util.HashMap;

import ratings.datastructures.Graph;

public class DegreesOfSeparation {

    public ArrayList<Movie> movieList;
    public Graph<String> castGraph;
    HashMap<String,Integer> visitList;
    ArrayList<String> nextCastList;
    public DegreesOfSeparation(ArrayList<Movie> l){
        castGraph = new Graph<String>();
        movieList = l;
        for(Movie currentMovie: movieList){
            ArrayList<String> castList = currentMovie.getCast();
            for (int curr =0; curr < castList.size();curr++){
                for (int ahead = curr+1; ahead < castList.size();ahead++){
                    String actor1 = castList.get(curr);
                    String actor2 = castList.get(ahead);
                    System.out.println("Adding edge between " + actor1 + " and " + actor2);  // debug statement
                    castGraph.addEdge(actor1, actor2);
                    castGraph.addEdge(actor2, actor1);
                }
            }
        }
        System.out.println("Adjacency list after construction: " + castGraph.getAdjacencyList());  // debug statement
    }

    public int degreesOfSeparation(String castMember1, String castMember2){
        int space = 0;
        if(castMember1.equals(castMember2)) return space;

        boolean check1 = false;
        boolean check2 = false;
        for(int i = 0; i < movieList.size();i++){
            for(int j = 0; j < movieList.get(i).getCast().size();j++){
                if(movieList.get(i).getCast().get(j).equals(castMember1)){
                    check1=true;
                }
                else if(movieList.get(i).getCast().get(j).equals(castMember2)) {
                    check2 = true;
                }
            }
        }
        if (check1 == false || check2 ==false) return -1;

        visitList = new HashMap<>();
        nextCastList = new ArrayList<>();

        visitList.put(castMember1,0);    //we entered cast1 because we started at that cast member
        nextCastList.add(castMember1);   //we will later remove this

        while (true){//if not empty we enter but we remove the first element and add the next cast member if it exist
            String actor = nextCastList.get(0);
            nextCastList.remove(0);
            space = visitList.get(actor);  //gets the current value from the key value pair, we will use this to find the separation
            for (String nextActor: castGraph.getAdjacencyList().get(actor)){    //next actor stores the actor in the index of castGraph where actor is stored in the adjacencyList
               if (visitList.containsKey(nextActor)==false){
                   nextCastList.add(nextActor);
                   visitList.put(nextActor,space+1);   //increments a space with the next actor
                   if (castMember2.equals(nextActor)){
                       return space+1;
                   }
               }
            }
            if (nextCastList.isEmpty()==true){
                break;
            }
        }

        space = -1;
        return space;
    }
}
