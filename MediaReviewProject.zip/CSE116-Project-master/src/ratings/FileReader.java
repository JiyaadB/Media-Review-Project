package ratings;

import com.sun.source.tree.ReturnTree;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import java.nio.file.Paths;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FileReader {

    public static ArrayList<Song> readSongs(String file){
        ArrayList<String> FileList = new ArrayList<String>();
        ArrayList<Song> ReturnList = new ArrayList<Song>();
        try{
            FileList = new ArrayList<String>(Files.readAllLines(Paths.get(file)));
            for(String read: FileList){
                ArrayList<String> Splits = new ArrayList<String>(Arrays.asList(read.split(",")));
                Song newsong = new Song(Splits.get(2), Splits.get(1), Splits.get(0));
                newsong.addRating(new Rating(Splits.get(3),Integer.parseInt(Splits.get(4))));
                boolean SongExist = false;
                for(Song x: ReturnList){
                    if(x.getSongID().equals(newsong.getSongID()) &&
                        x.getArtist().equals(newsong.getArtist()) &&
                        x.getTitle().equals(newsong.getTitle())){
                        x.addRating(new Rating(Splits.get(3),Integer.parseInt(Splits.get(4))));
                        SongExist = true;
                        break;
                    }
                }
                if(SongExist == false){
                    ReturnList.add(newsong);
                }
            }

        }
        catch(IOException exception){
            return new ArrayList<Song>();
        }
        return ReturnList;
    }

    public static ArrayList<Movie> readMovies(String File){
        ArrayList<String> FileList = new ArrayList<String>();
        ArrayList<Movie> ReturnList = new ArrayList<Movie>();
        try{
            FileList = new ArrayList<String>(Files.readAllLines(Paths.get(File)));
            for(String read: FileList){
                ArrayList<String> Splits = new ArrayList<String>(Arrays.asList(read.split(",")));
                if(Splits.size() < 2){
                    System.out.println("invalid format");
                    continue;
                }
                ArrayList<String> Cast = new ArrayList<String>();
                for(int i = 1; i < Splits.size(); i++){
                    Cast.add(Splits.get(i));
                }
                Movie movie = new Movie(Splits.get(0),Cast);
                ReturnList.add(movie);
            }

        }
        catch(IOException exception){
            return new ArrayList<Movie>();
        }
        return ReturnList;
    }

    public static ArrayList<Movie> readMovieRatings(ArrayList<Movie> list, String file){
        ArrayList<String> FileList = new ArrayList<String>();
        ArrayList<Movie> ReturnList = new ArrayList<Movie>();
        try{
            FileList = new ArrayList<String>(Files.readAllLines(Paths.get(file)));
            for(String read: FileList){
                ArrayList<String> Splits = new ArrayList<String>(Arrays.asList(read.split(",")));
                if(Splits.size() < 3){
                    System.out.println("invalid format");
                    continue;
                }
                for(Movie currMovie: list){
                    if(currMovie.getTitle().equals(Splits.get(0))){
                        Rating newRating = new Rating(Splits.get(1),Integer.parseInt(Splits.get(2)));
                        currMovie.addRating(newRating);
                        if(ReturnList.contains(currMovie)== false){
                            ReturnList.add(currMovie);
                        }
                    }
                }
            }

        }
        catch(IOException exception){
            return new ArrayList<Movie>();
        }
        return ReturnList;
    }
}
