package ratings.datastructures;

import ratings.Song;
public class SongBayesianRatingComparator extends Comparator<Song>{
    @Override
    public boolean compare(Song object1, Song object2){
        if(object1.bayesianAverageRating(2,3)> object2.bayesianAverageRating(2,3)){
            return true;
        }
        return false;
    }

}
