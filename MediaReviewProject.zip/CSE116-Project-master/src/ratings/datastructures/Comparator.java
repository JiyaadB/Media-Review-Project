package ratings.datastructures;

public class Comparator<T> {
    public boolean compare(T object1, T object2) {
        return false;
    }


}
