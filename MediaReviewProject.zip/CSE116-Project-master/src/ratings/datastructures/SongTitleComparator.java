package ratings.datastructures;

import ratings.Song;
public class SongTitleComparator extends Comparator<Song>{
    @Override
    public boolean compare(Song object1, Song object2){
        if(object1.getTitle().compareToIgnoreCase(object2.getTitle()) < 0) return true;
        return false;
    }
}
