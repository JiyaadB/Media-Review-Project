package ratings;

import java.util.ArrayList;

public class MediaLibrary {

    public ArrayList<Song> songList;

    public ArrayList<Movie> movieList;

    public ArrayList<Movie> movieRatingList;

    public MediaLibrary(){
        songList = new ArrayList<Song>();
        movieList = new ArrayList<Movie>();
        movieRatingList = new ArrayList<Movie>();
    }

    public void populateLibrary(String fileSong, String fileMovie, String fileMovieRatings){
        songList = FileReader.readSongs(fileSong);
        movieList = FileReader.readMovies(fileMovie);
        movieRatingList = FileReader.readMovieRatings(movieList,fileMovieRatings);
    }

    public ArrayList<Ratable> topKRatables(int input){

        if(input <= 0){
            return new ArrayList<Ratable>();
        }
        ArrayList<Ratable> returnList = new ArrayList<Ratable>();
        returnList.addAll(songList);
        returnList.addAll(movieRatingList);
        //using the built in arraylist to sort the list by there bayesianAverageRating
        returnList.sort((rating1,rating2)-> Double.compare(rating2.bayesianAverageRating(2,3),rating1.bayesianAverageRating(2,3)));
        if(input >= returnList.size()){
            return returnList;
        }
        ArrayList<Ratable> topList = new ArrayList<Ratable>();
        for(int i = 0; i < input; i++){
            topList.add(returnList.get(i));
        }
        return topList;
    }

    public ArrayList<Song> getSongList() {
        return songList;
    }

    public ArrayList<Movie> getMovieList() {
        return movieList;
    }

    public ArrayList<Movie> getMovieRatingList() {
        return movieRatingList;
    }
}
