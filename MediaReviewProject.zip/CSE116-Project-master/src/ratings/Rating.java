package ratings;

public class Rating {
    public String ID;

    public int rating;


    public Rating(String I, int r){
        setRating(r);
        this.ID = I;
    }

    public String getReviewerID(){
        return ID;
    }

    public void setReviewerID(String I){
        ID = I;
    }

    public int getRating(){
        return rating;
    }

    public void setRating(int r){
        if(r >= 1 && r <= 5){
            this.rating = r;
        }
        else{
            this.rating = -1;
        }
    }
}
