package ratings;

import ratings.datastructures.LinkedListNode;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Movie extends Ratable {
    public ArrayList<String> Cast;
    public LinkedListNode<Rating> list;



    public Movie(String T, ArrayList<String> C){
        setTitle(T);
        this.Cast = C;
        this.list = null;


    }
    public ArrayList<String> getCast(){
        return new ArrayList<String>(this.Cast);
    }

}
