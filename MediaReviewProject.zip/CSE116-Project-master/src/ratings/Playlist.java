package ratings;

import org.w3c.dom.Node;
import ratings.datastructures.BinaryTreeNode;
import ratings.datastructures.Comparator;
import ratings.datastructures.LinkedListNode;
import ratings.datastructures.SongTitleComparator;
import ratings.datastructures.SongTitleComparator.*;

public class Playlist {
    public int Count;
    public Comparator<Song> Compare;
    public BinaryTreeNode<Song> songs;

    public Playlist(Comparator<Song> C) {
        this.Compare = C;
        this.Count = 0;
    }

    public void addSong(Song add){
        BinaryTreeNode<Song> AddedNode = new BinaryTreeNode<Song>(add, null, null); //create a new node to store the added song
        if(songs == null){
            songs = AddedNode;
        }
        else{
            BinaryTreeNode<Song> CurrentNode = songs;
            BinaryTreeNode<Song> DummyNode = null;
            while(CurrentNode != null){
                DummyNode = CurrentNode;
                if(Compare.compare(add, DummyNode.getValue()) == false){
                    CurrentNode = CurrentNode.getRight();
                }
                else{
                    CurrentNode = CurrentNode.getLeft();
                }
            }
            if(Compare.compare(add,DummyNode.getValue())== false){
                DummyNode.setRight(AddedNode);
            }
            else{
                DummyNode.setLeft(AddedNode);
            }
        }
    }
    public BinaryTreeNode<Song> getSongTree() {
        return songs;
    }

    public LinkedListNode<Song> getSongList(BinaryTreeNode<Song> HeadNode){
        if(HeadNode == null) return null;  // we return null if the node passed in the parameters = null
        LinkedListNode<Song> BeginningList = getSongList(HeadNode.getLeft());  //contains smallest value of left side of tree
        LinkedListNode<Song> EndList = getSongList(HeadNode.getRight()); //contains smallest value of the right side of tree

        LinkedListNode<Song> NodeValue = new LinkedListNode<>(HeadNode.getValue(), null);
        NodeValue.setNext(EndList);  // Adds EndsList to the end of the node value list
        if(BeginningList == null){
            BeginningList = NodeValue;
        }
        else{
            LinkedListNode<Song> DummyNode = BeginningList;  //creates a DummyNode that is a copy of the beginning of our list
            while(DummyNode.getNext() != null){  //iterates through the list
                DummyNode = DummyNode.getNext();
            }
            DummyNode.setNext(NodeValue);  // adds beginninglist and endlist together
        }

        return BeginningList; //returns entire list
        //I believe this is efficient logic but let me know if there is any other errors professor!
    }
    public LinkedListNode<Song> getSongList(){
        return getSongList(songs);
    }
}
