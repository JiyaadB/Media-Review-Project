package ratings;

import java.util.ArrayList;
import java.util.HashMap;

public class ProblemSet {


    public static double average(ArrayList<Double> numbers) { // starting code that defines a public static method "average" that takes an array list of Doubles for an input
        if(numbers.size() == 0 ) // Checks if the size of the ArrayList named "numbers" equals to zero
            return 0.0;  //return 0.0 from if it does = 0
         double sum = 0; //Declares and initializes a variable name sum to a double value which is 0
         int length = numbers.size(); // declares a variable named length of type int and stores the size of numbers in an arraylist
         for(int i = 0; i < length; i++ ){ // begins a loop that iterates over each element of the ArrayList.
             sum += numbers.get(i); // adds the value of 'ith index' in the 'numbers' ArrayList to the "sum" variable and it accumulates the sum of all numbers in the array
         }
        return sum / (double) length;  // Line calculates the average of the numbers by dividing sum by the length and returns the result as a double value.

        // TODO: Implement this method to return the average of all the numbers in the input ArrayList
        //       If the ArrayList is empty, return 0.0
        //
        // Examples
        // [1.0,2.0,3.0] returns 2.0
        // [-5.0,5.0] returns 0.0
        // [6.5,6.5,8.5,8.5] returns 7.5
        // [] returns 0.0

    }


    // TODO: Write a public static method named sumOfDigits that takes an int as a parameter and
    //       returns the sum of the digits of the input as an int
    //
    // Examples
    // 123 returns 6
    // 57 returns 12
    // -36 returns 9
    public static int sumOfDigits(int number){ // the starter code or method for sumOfDigits that takes an integer parameter named numbers
        int sum = 0; // declares and initializes a variable named sum of type int with an initial value of 0. will be used to accumulate the sum
        number = Math.abs(number); // uses the Math.abs() function to convert the input number to its absolute value.
        while(number > 0 ){  //  starts a while loop that continues as long as number is greater than 0.
            sum += number %10;  //
            number = number/10;  //

        }
        return sum;
    }

    // TODO: Write a public static method named bestKey that takes a HashMap of String to Integer
    //       as a parameter and returns a key mapping to the largest Integer. Ties can be broken arbitrarily.
    //       If the HashMap is empty, return the empty String
    //
    // Examples
    // {"CSE": 100, "MTH": 90, "MGT": 10} returns "CSE"
    // {"cat": 5, "dog": 5, "fox": 4} can return either "cat" or "dog"
    // {} returns ""
    public static String bestKey(HashMap <String, Integer> map ){
        String HighestKey = "";
        if(map.isEmpty()){
            return HighestKey;
        }
        int HighestNumber = Integer.MIN_VALUE;
        for(String currentKey :map.keySet() ){
            if (map.get(currentKey) > HighestNumber){
                HighestNumber = map.get(currentKey);
                HighestKey = currentKey;

            }
        }
        return HighestKey;

    }
}
