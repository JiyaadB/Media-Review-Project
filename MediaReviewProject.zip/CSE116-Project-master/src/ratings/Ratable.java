package ratings;

import ratings.datastructures.LinkedListNode;

public class Ratable {

    public String title;

    public LinkedListNode<Rating> list;

    public String getTitle(){
        return title;
    }

    public void setTitle(String t){
        title = t;
    }

    public void addRating(Rating R){
        boolean check = didReviewerRateSong(R.getReviewerID());
        if(check == false){
            if(list == null){
                this.list = new LinkedListNode<Rating>(R, null);


            }
            else this.list.append(R);
        }



    }

    public LinkedListNode<Rating> getRatings(){
        if(list == null) return null;
        return list;

    }

    public double averageRating(){
        if(list == null) return 0.0;
        double sum =0.0;
        LinkedListNode<Rating> dummyNode = list;
        while(dummyNode != null){
            sum += dummyNode.getValue().rating;
            dummyNode = dummyNode.getNext();
        }
        return sum/list.size();
    }

    public boolean didReviewerRateSong(String I){
        if(list == null) return false;
        LinkedListNode<Rating> dummyNode = list;
        while(dummyNode != null){
            if(dummyNode.getValue().ID.equals(I)) return true;
            dummyNode = dummyNode.getNext();
        }
        return false;

    }
    public void removeRatingByReviewer(Reviewer R){
        String ID = R.getReviewerID();
        if(list == null) return;
        if(list.getValue().getReviewerID().equals(ID)){
            list = list.getNext();
        }
        LinkedListNode<Rating> dummyNode = list;
        while(dummyNode != null){
            if(dummyNode.getNext() == null) break;
            if(dummyNode.getNext().getValue().getReviewerID().equals(ID)){
                dummyNode.setNext(dummyNode.getNext().getNext());
                break;
            }
            dummyNode = dummyNode.getNext();
        }

    }

    public double bayesianAverageRating(int num, int val){
        if(list == null && num == 0) return 0.0;
        double sum =0.0;
        LinkedListNode<Rating> dummyNode = list;
        while(dummyNode != null){
            sum += dummyNode.getValue().getRating();
            dummyNode = dummyNode.getNext();
        }
        for(int i = 0; i < num; i ++){
            sum += val;
        }
        if(list == null){
            return sum/num;
        }
        else
            return sum/(double)(list.size()+num);
    }




}
