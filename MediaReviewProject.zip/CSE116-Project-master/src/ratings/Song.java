package ratings;


import ratings.datastructures.LinkedListNode;

public class Song extends Ratable{
    public String artist;
    public String ID;

    public Song(String t, String a, String I){
        setTitle(t);
        this.artist = a;
        this.ID = I;
        this.list = null;
    }

    public String getArtist(){
        return artist;
    }

    public void setArtist(String a){
        artist = a;
    }
    public String getSongID(){
        return ID;
    }

    public void setSongID(String I){
        ID = I;
    }
}


