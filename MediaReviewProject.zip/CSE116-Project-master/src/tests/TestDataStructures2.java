package tests;

import ratings.*;
import org.junit.Test;
import ratings.datastructures.BinaryTreeNode;
import ratings.datastructures.Comparator;
import ratings.datastructures.LinkedListNode;
import ratings.datastructures.SongTitleComparator;

import java.sql.SQLOutput;
import java.util.ArrayList;

import static org.junit.Assert.*;


public class TestDataStructures2 {

    @Test
    public void TestPlaylistConstructor(){
        Comparator<Song> comparator = new SongTitleComparator();
        Playlist list = new Playlist(comparator);
        assertNull(list.getSongList());
    }

    @Test
    public void TestAddSong(){
        Comparator<Song> comparator = new SongTitleComparator();
        Playlist list = new Playlist(comparator);
        Song song1 = new Song("LOVE", "Kendrick Lamar","vabnZ9-ex7o");
        Song song2 = new Song("Some Girl", "GoldLink","vabnZ9-eo6p");
        Song song3 = new Song("Gang Activities", "Baby Keem","vabnZ9-ec9p");

        list.addSong(song1);
        list.addSong(song2);
        list.addSong(song3);

        // Assertions done here

        BinaryTreeNode<Song> Head = list.getSongTree();
        assertEquals(song1,Head.getValue());
        assertEquals(song2,Head.getRight().getValue());
        assertEquals(song3,Head.getLeft().getValue());
        assertEquals(Head,list.getSongTree());
    }

    @Test
    public void TestGetSongListNoSongs(){
        Comparator<Song> comparator = new SongTitleComparator();
        Playlist list = new Playlist(comparator);
        assertEquals(list.getSongList(),null);

    }

    @Test
    public void TestGetSongList(){
        Comparator<Song> comparator = new SongTitleComparator();
        Playlist list = new Playlist(comparator);

        Song song1 = new Song("Money Trees", "Kendrick Lamar","vabnZ9-ex7o");
        Song song2 = new Song("Crew", "GoldLink","vabnZ9-eo6p");
        Song song3 = new Song("So What?", "Baby Keem","vabnZ9-ec9p");
        list.addSong(song1);
        list.addSong(song2);
        list.addSong(song3);
        LinkedListNode<Song> SongList = new LinkedListNode<Song>(song2,null);
        SongList.append(song1);
        SongList.append(song3);
        BinaryTreeNode<Song> Head = list.getSongTree();
        LinkedListNode<Song> SongListActual = list.getSongList(Head);
        while(SongListActual != null && SongList != null){
            assertEquals(SongListActual.getValue(),SongList.getValue());
            SongListActual = SongListActual.getNext();
            SongList = SongList.getNext();
        }
    }

    @Test
    public void TestPlayListMoreThanThreeSongs(){
        Comparator<Song> comparator = new SongTitleComparator();
        Playlist list = new Playlist(comparator);

        Song song1 = new Song("Money Trees", "Kendrick Lamar","vabnZ9-ex7o");
        Song song2 = new Song("Crew", "GoldLink","vabnZ9-eo6p");
        Song song3 = new Song("Telephone", "Vacations","vabnZ9-es2p");
        Song song4 = new Song("So What?", "Baby Keem","vabnZ9-ec9p");
        Song song5 = new Song("range brothers", "Baby Keem","vabnZ9-et1p");
        Song song6 = new Song("Mercury", "Steve Lacy","vabnZ9-ez5p");
        list.addSong(song1);
        list.addSong(song2);
        list.addSong(song3);
        list.addSong(song4);
        list.addSong(song5);
        list.addSong(song6);
        LinkedListNode<Song> SongList = new LinkedListNode<Song>(song2,null);
        SongList.append(song6);
        SongList.append(song1);
        SongList.append(song5);
        SongList.append(song4);
        SongList.append(song3);

        LinkedListNode<Song> SongListActual = list.getSongList();
        if(SongListActual.size()!= SongList.size()){
            assertTrue(false);
        }
        while(SongListActual != null && SongList != null){
            assertEquals(SongListActual.getValue(),SongList.getValue());
            SongListActual = SongListActual.getNext();
            SongList = SongList.getNext();
        }

    }

    @Test
    public void TestPlayListMissingSong(){
        Comparator<Song> comparator = new SongTitleComparator();
        Playlist list = new Playlist(comparator);
        Song song1 = new Song("Money Trees", "Kendrick Lamar","vabnZ9-ex7o");
        Song song2 = new Song("Crew", "GoldLink","vabnZ9-eo6p");

        list.addSong(song1);
        list.addSong(song2);
        LinkedListNode<Song> SongList = list.getSongList();
        assertTrue(Contains(SongList,song1));
        assertTrue(Contains(SongList,song2));
    }
    public boolean Contains(LinkedListNode<Song> list, Song song){
        LinkedListNode<Song> DummyNode = list;
        while(DummyNode != null){
            if(DummyNode.getValue().equals(song)){
                return true;
            }
            DummyNode = DummyNode.getNext();
        }
        return false;
    }
}
