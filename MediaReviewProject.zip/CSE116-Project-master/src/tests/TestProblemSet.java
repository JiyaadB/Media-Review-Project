package tests;

import org.junit.Test;
import ratings.ProblemSet;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestProblemSet {

    // TODO: Write testing for all 3 methods of the ratings.ProblemSet class
    public final double nums = 0.001;

   @Test
    public void sumOfDigitsTest(){
       int sumtest1 = ProblemSet.sumOfDigits(123);
       assertTrue(sumtest1 == 6);

       int sumtest2 = ProblemSet.sumOfDigits(-36);
       assertTrue(sumtest2 == 9);

       int sumtest3 = ProblemSet.sumOfDigits(57);
       assertTrue(sumtest3 == 12);
   }


   @Test
   public void averageTest(){
       ArrayList<Double> list1 = new ArrayList<Double>();
       list1.add(1.0);
       list1.add(2.0);
       list1.add(3.0);

       assertEquals(2.0,ProblemSet.average(list1), nums);

       ArrayList<Double> list2 = new ArrayList<Double>();

       assertEquals(0.0,ProblemSet.average(list2), nums);

       ArrayList<Double> list3 = new ArrayList<Double>();
       list3.add(6.0);

       assertEquals(6.0, ProblemSet.average(list3), nums);

       ArrayList<Double> list4 = new ArrayList<Double>();
       list4.add(1.0);
       list4.add(2.0);
       list4.add(3.0);
       list4.add(4.0);
       list4.add(5.0);
       list4.add(6.0);
       list4.add(7.0);
       list4.add(8.0);
       list4.add(9.0);
       list4.add(10.0);
       list4.add(11.0);
       list4.add(12.0);

       assertEquals(6.5, ProblemSet.average(list4), nums);

   }

   @Test
   public void bestKeyTest(){
       HashMap <String, Integer> map1 = new HashMap<String, Integer>();
       map1.put("CSE",100);
       map1.put("MTH", 90);
       map1.put("MGT", 10);

       assertTrue(ProblemSet.bestKey(map1)=="CSE");

       HashMap <String, Integer> map2 = new HashMap<String, Integer>();
       map2.put("cat", 5);
       map2.put("dog", 5);
       map2.put("fox", 4);

       assertTrue(ProblemSet.bestKey(map2)=="cat" || ProblemSet.bestKey(map2) == "dog");


       HashMap <String, Integer> map3 = new HashMap<String, Integer>();
       assertTrue(ProblemSet.bestKey(map3)=="");

       HashMap <String, Integer> map4 = new HashMap<String, Integer>();
       map4.put("cat", -5);
       map4.put("dog", -4);
       map4.put("fox", -3);

       assertTrue(ProblemSet.bestKey(map4)=="fox");

   }


}



