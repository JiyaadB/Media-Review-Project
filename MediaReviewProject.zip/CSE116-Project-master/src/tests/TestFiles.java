package tests;

import ratings.*;
import org.junit.Test;
import ratings.datastructures.LinkedListNode;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.*;

public class TestFiles {

    @Test
    public void MovieFileDoesNotExist(){
        String TestFilePath = "";
        ArrayList<Movie> Result = FileReader.readMovies(TestFilePath);
        assertTrue(Result.isEmpty());
    }

    @Test
    public void TestReadMovie(){
        String TestFilePath = "data/moviestest1.csv";
        ArrayList<Movie> Result = FileReader.readMovies(TestFilePath);
        assertEquals(7,Result.size());
    }

    @Test
    public void TestGrabMovie(){
        String TestFilePath = "data/moviestest1.csv";
        ArrayList<Movie> Result = FileReader.readMovies(TestFilePath);
        Movie TestMovie = Result.get(0);
        assertEquals("Toy Story",TestMovie.getTitle());
    }

    @Test
    public void TestMovieCast(){
        String TestFilePath = "data/moviestest1.csv";
        ArrayList<Movie> Result = FileReader.readMovies(TestFilePath);
        ArrayList<String> Cast = Result.get(0).getCast();
        ArrayList<String> TestCast = new ArrayList<String>();
//        Tom Hanks,Tim Allen,Don Rickles,Wallace Shawn,John Ratzenberger,Annie Potts,John Morris,Laurie Metcalf,R. Lee Ermey,Penn Jillette
        TestCast.add("Tom Hanks");
        TestCast.add("Tim Allen");
        TestCast.add("Don Rickles");
        TestCast.add("Wallace Shawn");
        TestCast.add("John Ratzenberger");
        TestCast.add("Annie Potts");
        TestCast.add("John Morris");
        TestCast.add("Laurie Metcalf");
        TestCast.add("R. Lee Ermey");
        TestCast.add("Penn Jillette");
        assertEquals(Cast,TestCast);
    }

    @Test
    public void TestSongNoFile(){
        String TestFilePath = "";
        ArrayList<Song> Result = FileReader.readSongs(TestFilePath);
        assertTrue(Result.isEmpty());
    }

    @Test
    public void TestReadSongs(){
        String TestFilePath = "data/ratings.csv";
        ArrayList<Song> Result = FileReader.readSongs(TestFilePath);
        assertEquals(313,Result.size());
    }

    @Test
    public void TestGetSong(){
        String TestFilePath = "data/ratings.csv";
        ArrayList<Song> Result = FileReader.readSongs(TestFilePath);

        Song TestSong = null;
        for(Song x: Result){
            if(x.getTitle().equals("Roses") && x.getArtist().equals("Outkast")){
                TestSong = x;
                break;
            }
        }
        assertNotNull(TestSong);

        assertEquals("Roses",TestSong.getTitle());
        assertEquals("Outkast",TestSong.getArtist());

        LinkedListNode<Rating> RatingList = TestSong.getRatings();
        ArrayList<Integer> testRating = new ArrayList<>();
        while (RatingList != null) {
            testRating.add(RatingList.getValue().getRating());
            RatingList = RatingList.getNext();
        }


        ArrayList<Integer> expectedRatings = new ArrayList<>(Arrays.asList(5, 2, 5));
        assertTrue(testRating.containsAll(expectedRatings));
    }

    @Test
    public void TestSongRatingOrder(){
        String TestFilePath = "data/ratings.csv";
        ArrayList<Song> Result = FileReader.readSongs(TestFilePath);

        Song TestSong = null;
        for(Song x: Result){
            if(x.getTitle().equals("Moon Song") && x.getArtist().equals("Phoebe Bridgers")){
                TestSong = x;
                break;
            }
        }
        assertNotNull(TestSong);
        LinkedListNode<Rating> RatingList = TestSong.getRatings();
        ArrayList<Integer> testRating = new ArrayList<>();
        while (RatingList != null) {
            testRating.add(RatingList.getValue().getRating());
            RatingList = RatingList.getNext();
        }
        ArrayList<Integer> expectedRatings = new ArrayList<>(Arrays.asList(5,3,3,3,5,3,4,4,5,2,3,5,3,5,3,5));
        assertEquals(expectedRatings,testRating);
    }
}