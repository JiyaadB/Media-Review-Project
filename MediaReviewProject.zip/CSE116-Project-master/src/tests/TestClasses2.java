package tests;

import ratings.*;
import org.junit.Test;
import ratings.datastructures.LinkedListNode;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


public class TestClasses2 {

    public final double nums = 0.001;

    public void compareDoubles(double d1, double d2) {
        assertTrue(d1 + " and " + d2 + " are not within " + nums, Math.abs(d1 - d2) < nums);

    }

    public void compareRatings(Rating computed, Rating expected) {
        assertTrue(computed.getRating() == expected.getRating());
        assertTrue(computed.getReviewerID().equals(expected.getReviewerID()));
    }

    public void checkRatingsList(LinkedListNode<Rating> computed, LinkedListNode<Rating> expected) {
        if (expected == null) {
            assertTrue(computed == null);
        } else {
            assertTrue(computed != null);
            compareRatings(computed.getValue(), expected.getValue());
            checkRatingsList(computed.getNext(), expected.getNext());
        }
    }

    public void addAllRatings(Movie movies, LinkedListNode<Rating> ratings) {
        if (ratings != null) {
            movies.addRating(ratings.getValue());
            addAllRatings(movies, ratings.getNext());
        }
    }

    public void addAllSongRatings(Song songs, LinkedListNode<Rating> ratings) {
        if (ratings != null) {
            songs.addRating(ratings.getValue());
            addAllSongRatings(songs, ratings.getNext());
        }
    }


    @Test
    public void testMovieClass() {
        ArrayList<String> Cast = new ArrayList<String>();
        Cast.add("Jackie Chan");
        Cast.add("Jaden Smith");
        Movie movie = new Movie("Karate Kid", Cast);
        ArrayList<String> dupeCast = movie.getCast();

        assertEquals(Cast.size(), dupeCast.size());

        for (int i = 0; i < Cast.size(); i++) {
            assertTrue(Cast.get(i).equalsIgnoreCase(dupeCast.get(i)));
        }

        assertTrue(movie.getTitle().equals("Karate Kid"));

    }

    @Test
    public void testMovieTitle(){
        ArrayList<String> Cast = new ArrayList<String>();
        Cast.add("Adam Sandler");
        Movie movie = new Movie("Click", Cast);
        assertTrue(movie.getTitle().equals("Click"));

        ArrayList<String> Cast2 = new ArrayList<String>();
        Cast2.add("Adam Sandler");
        Cast2.add("Selena Gomez");
        Movie movie2 = new Movie("Hotel Transylvania", Cast2);
        assertTrue(movie2.getTitle().equals("Hotel Transylvania"));

    }

    @Test
    public void testMovieCast(){
        ArrayList<String> Cast = new ArrayList<String>();
        Cast.add("Adam Sandler");
        Cast.add("Selena Gomez");
        Movie movie = new Movie("Hotel Transylvania", Cast);
        ArrayList<String> movieCast = movie.getCast();

        assertEquals(Cast.size(), movieCast.size());

        for (int i = 0; i < Cast.size(); i++) {
            assertTrue(Cast.get(i).equalsIgnoreCase(movieCast.get(i)));
        }

        ArrayList<String> Cast2 = new ArrayList<String>();
        Cast2.add("Jim Carrey");
        Movie movie2 = new Movie("Mr. Poppin Penguins", Cast2);
        ArrayList<String> movieCast2 = movie2.getCast();

        assertEquals(Cast2.size(), movieCast2.size());

        for (int i = 0; i < Cast2.size(); i++) {
            assertTrue(Cast2.get(i).equalsIgnoreCase(movieCast2.get(i)));
        }

        ArrayList<String> Cast3 = new ArrayList<String>();
        Movie movie3 = new Movie("No Cast", Cast3);
        ArrayList<String> movieCast3 = movie3.getCast();

        assertEquals(Cast3.size(), movieCast3.size());

        for (int i = 0; i < Cast3.size(); i++) {
            assertTrue(Cast3.get(i).equalsIgnoreCase(movieCast3.get(i)));
        }
    }

    @Test
    public void testMovieBayesianAverageRatingWithNoRatings(){
        LinkedListNode<Rating> expected = null;
        ArrayList<String> Cast = new ArrayList<String>();
        Cast.add("Toby Mcguire");
        Cast.add("Stan Lee");
        Cast.add("Willem Dafoe");

        Movie movie = new Movie("Spider-Man 2", Cast);
        addAllRatings(movie, expected);
        assertEquals(3.0, movie.bayesianAverageRating(2, 3), nums);
    }

    @Test
    public void testMovieBayesianAverageRatingWithZeroAdditionalRatings(){
        LinkedListNode<Rating> expected = new LinkedListNode<>(new Rating("Jesse", 4), null);
        expected = new LinkedListNode<>(new Rating("Paul", 4), expected);
        ArrayList<String> Cast = new ArrayList<String>();
        Cast.add("Toby Mcguire");
        Cast.add("Stan Lee");
        Cast.add("Willem Dafoe");

        Movie movie = new Movie("Spider-Man 2", Cast);
        addAllRatings(movie, expected);
        assertEquals(4.0, movie.bayesianAverageRating(0, 3), nums);
        assertEquals(4.0, movie.bayesianAverageRating(0, 1), nums);
    }

    @Test
    public void testMovieBayesianAverageRatingWithDifferentInputs(){
        LinkedListNode<Rating> expected = new LinkedListNode<>(new Rating("Jesse", 4), null);
        expected = new LinkedListNode<>(new Rating("Paul", 3), expected);
        expected = new LinkedListNode<>(new Rating("Aaron", 2), expected);
        ArrayList<String> Cast = new ArrayList<String>();
        Cast.add("Toby Mcguire");
        Cast.add("Stan Lee");
        Cast.add("Willem Dafoe");

        Movie movie = new Movie("Spider-Man 2", Cast);
        addAllRatings(movie, expected);
        assertEquals(3.0, movie.bayesianAverageRating(2, 3), nums);
    }


    @Test
    public void testAddRatingsWithoutDuplicateReviewerIDs() {
        LinkedListNode<Rating> expected = new LinkedListNode<>(new Rating("Jesse", 3), null);
        expected = new LinkedListNode<>(new Rating("Paul", 4), expected);
        expected = new LinkedListNode<>(new Rating("Carl", 5), expected);
        ArrayList<String> Cast = new ArrayList<String>();
        Cast.add("Toby Mcguire");
        Cast.add("Stan Lee");
        Cast.add("Willem Dafoe");

        Movie movie = new Movie("Spider-Man 2", Cast);
        assertTrue(movie.getRatings() == null);
        addAllRatings(movie, expected);

        LinkedListNode<Rating> computed = movie.getRatings();
        checkRatingsList(computed, expected);
    }

    @Test
    public void testMovieBayesianAverageRating() {
        LinkedListNode<Rating> expected = new LinkedListNode<>(new Rating("Jesse", 4), null);
        expected = new LinkedListNode<>(new Rating("Paul", 4), expected);
        ArrayList<String> Cast = new ArrayList<String>();
        Cast.add("Toby Mcguire");
        Cast.add("Stan Lee");
        Cast.add("Willem Dafoe");

        Movie movie = new Movie("Spider-Man 2", Cast);
        addAllRatings(movie, expected);
        assertEquals(3.5, movie.bayesianAverageRating(2, 3), nums);
    }

    @Test
    public void testSongBayesianAverageRating() {
        LinkedListNode<Rating> expected = new LinkedListNode<>(new Rating("Jesse", 4), null);
        expected = new LinkedListNode<>(new Rating("Paul", 4), expected);

        Song songs = new Song("LOVE", "Kendrick Lamar", "vabnZ9-ex7o");
        addAllSongRatings(songs, expected);
        assertEquals(3.5, songs.bayesianAverageRating(2, 3), nums);

        LinkedListNode<Rating> expected2 = new LinkedListNode<>(new Rating("Arun",4), null);
        expected2 = new LinkedListNode<>(new Rating("Paul", 5), expected2);
        Song songs2 = new Song("N side", "Steve Lacy", "vabnZ9-ex7o");
        addAllSongRatings(songs2, expected2);
        assertEquals(3.75, songs2.bayesianAverageRating(2, 3), nums);

    }

    @Test
    public void testSongBayesianAverageRatingWithNoRatings(){
        LinkedListNode<Rating> expected = null;

        Song songs = new Song("LOVE", "Kendrick Lamar", "vabnZ9-ex7o");
        addAllSongRatings(songs, expected);
        assertEquals(3.0, songs.bayesianAverageRating(2, 3), nums);
    }

    @Test
    public void testSongBayesianAverageRatingWithZeroAdditionalRatings(){
        LinkedListNode<Rating> expected2 = new LinkedListNode<>(new Rating("Arun",4), null);
        expected2 = new LinkedListNode<>(new Rating("Paul", 5), expected2);
        Song songs2 = new Song("N side", "Steve Lacy", "vabnZ9-ex7o");
        addAllSongRatings(songs2, expected2);
        assertEquals(4.5, songs2.bayesianAverageRating(0, 3), nums);
    }

    @Test
    public void testSongBayesianAverageRatingWithDifferentInputs(){
        LinkedListNode<Rating> expected2 = new LinkedListNode<>(new Rating("Arun",4), null);
        expected2 = new LinkedListNode<>(new Rating("Paul", 5), expected2);
        expected2 = new LinkedListNode<>(new Rating("Jimmy", 3), expected2);
        expected2 = new LinkedListNode<>(new Rating("Justin", 2), expected2);
        expected2 = new LinkedListNode<>(new Rating("sahinin", 1), expected2);
        Song songs2 = new Song("N side", "Steve Lacy", "vabnZ9-ex7o");
        addAllSongRatings(songs2, expected2);
        assertEquals(3.0, songs2.bayesianAverageRating(1, 3), nums);
    }

    @Test
    public void testSongBayesianAverageRatingZeroRatings(){
        LinkedListNode<Rating> expected = null;
        Song songs2 = new Song("N side", "Steve Lacy", "vabnZ9-ex7o");
        addAllSongRatings(songs2, expected);
        assertEquals(0.0, songs2.bayesianAverageRating(0, 3), nums);
    }

}
