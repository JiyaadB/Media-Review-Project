package tests;

import ratings.*;
import org.junit.Test;
import ratings.datastructures.LinkedListNode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

public class TestClasses3 {

    @Test
    public void TestMovieRatings(){
        ArrayList<Movie> ratings = new ArrayList<Movie>();
        ArrayList<Movie> movieList = new ArrayList<Movie>();
        movieList = FileReader.readMovies("data/movie_test2.csv");
        ratings = FileReader.readMovieRatings(movieList,"data/movie_ratings1.csv");
        assertTrue(!ratings.isEmpty());
        Map<String, Double> titleCheck = new HashMap<String,Double>();
        titleCheck.put("Rocky III",2.0);
        titleCheck.put("American Pie",4.0);
        titleCheck.put("Jay and Silent Bob Strike Back",2.0);
        titleCheck.put("2001: A Space Odyssey",3.0);
        titleCheck.put("Three Colors: Red",4.0);
        titleCheck.put("48 Hrs.",5.0);
        titleCheck.put("Ocean's Eleven",3.0);
        titleCheck.put("Back to the Future Part II",3.0);
        assertEquals(titleCheck.size(),ratings.size());
        for(Movie currMovie: ratings){
            assertTrue(titleCheck.containsKey(currMovie.getTitle()));
            assertEquals(titleCheck.get(currMovie.getTitle()),currMovie.averageRating(),0.0001);
        }
    }
    @Test
    public void TestMultipleMovieRatings(){
        ArrayList<Movie> ratings = new ArrayList<Movie>();
        ArrayList<Movie> movieList = new ArrayList<Movie>();
        movieList = FileReader.readMovies("data/movie_test2.csv");
        ratings = FileReader.readMovieRatings(movieList,"data/movie_ratings2.csv");
        assertTrue(!ratings.isEmpty());
        double[] expected = new double[]{2.0,4.0,3.0,5.0};
        String title = "Rocky III";
        Movie findMovie = null;
        for(Movie currMovie: ratings){
            if(currMovie.getTitle().equals(title)){
                findMovie = currMovie;
                break;
            }
        }
        assertNotNull(findMovie);

        LinkedListNode<Rating> ratingCheck = findMovie.getRatings();
        assertTrue(ratingCheck.size()==4);
        for(double currentRating: expected){
            assertNotNull(ratingCheck);
            assertEquals(currentRating,ratingCheck.getValue().getRating(),0.0001);
            ratingCheck = ratingCheck.getNext();
        }
        assertNull(ratingCheck);  //checks that there is no more ratings
    }

    @Test
    public void TestNoFile(){
        ArrayList<Movie> ratings = new ArrayList<Movie>();
        ArrayList<Movie> movieList = new ArrayList<Movie>();
        movieList = FileReader.readMovies("");
        assertTrue(movieList.isEmpty());
        movieList = FileReader.readMovies("data/movie_test2.csv");
        assertTrue(!movieList.isEmpty());
        ratings = FileReader.readMovieRatings(movieList,"");
        assertTrue(ratings.isEmpty());
        ratings = FileReader.readMovieRatings(movieList,"data/movie_ratings1.csv");
        assertTrue(!ratings.isEmpty());
    }

    @Test
    public void TestMediaLibrary() {
        MediaLibrary library = new MediaLibrary();
        library.populateLibrary("data/ratings.csv", "data/movie_test2.csv", "data/movie_ratings1.csv");

        ArrayList<Ratable> rateList = new ArrayList<Ratable>();
        rateList = library.topKRatables(5);
        assertNotNull(rateList);
        assertEquals(rateList.size(), 5);
        ArrayList<String> titleList = new ArrayList<String>(Arrays.asList("Ice So White","20 mins","Through The Wire","Cupid - Twin Ver.","la mama de la mama"));
        for (int i = 0; i < rateList.size(); i++){
            assertTrue(rateList.get(i).getTitle().equals(titleList.get(i)));
        }
    }

    @Test
    public void TestNoKBigK(){
        MediaLibrary library = new MediaLibrary();
        library.populateLibrary("data/ratings.csv", "data/movie_test2.csv", "data/movie_ratings1.csv");
        ArrayList<Ratable> rateList = new ArrayList<Ratable>();
        rateList = library.topKRatables(0);
        assertNotNull(rateList);
        assertEquals(rateList.size(), 0);
        rateList = library.topKRatables(400);
        assertNotNull(rateList);
        assertEquals(rateList.size(), 321);
    }
}

