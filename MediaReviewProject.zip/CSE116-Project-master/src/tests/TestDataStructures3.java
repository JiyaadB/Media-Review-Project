package tests;

import ratings.*;
import org.junit.Test;
import ratings.datastructures.Graph;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class TestDataStructures3 {


    @Test
    public void TestNotInCast(){
        ArrayList<Movie> list = FileReader.readMovies("data/movietest1.csv");
        DegreesOfSeparation separation = new DegreesOfSeparation(list);

        int check = separation.degreesOfSeparation("Arun Patiram","Shaine Lomenario");
        assertEquals(check,-1);
    }

    @Test
    public void TestSameActor(){
        ArrayList<Movie> list = FileReader.readMovies("data/movietest1.csv");
        DegreesOfSeparation separation = new DegreesOfSeparation(list);

        int check = separation.degreesOfSeparation("Brad Pitt","Brad Pitt");
        assertEquals(check,0);
    }

    @Test
    public void TestSameCast(){
        ArrayList<Movie> list = FileReader.readMovies("data/movie_test2.csv");
        DegreesOfSeparation separation = new DegreesOfSeparation(list);

        int check = separation.degreesOfSeparation("Jason Biggs","Chris Klein");

        assertEquals(check,1);
    }

    @Test
    public void TestNoSameMovie(){
        ArrayList<Movie> list = FileReader.readMovies("data/movies.csv");
        DegreesOfSeparation separation = new DegreesOfSeparation(list);

        int check = separation.degreesOfSeparation("Chris Pratt","Kevin Bacon");

        assertEquals(2,check);

    }
}
